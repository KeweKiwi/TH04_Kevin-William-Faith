﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Kevin_William_Faith
{
    internal class Team
    {
        private string teamName;
        private string teamCountry;
        private string teamCity;
        private List<Player> players;

        public Team(string teamName, string teamCountry, string teamCity, List<Player> players)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            this.players = players;
        }

        public string TeamName { get => teamName; set => teamName = value; }
        public string TeamCountry { get => teamCountry; set => teamCountry = value; }
        public string TeamCity { get => teamCity; set => teamCity = value; }
        internal List<Player> Players { get => players; set => players = value; }
    }
}
