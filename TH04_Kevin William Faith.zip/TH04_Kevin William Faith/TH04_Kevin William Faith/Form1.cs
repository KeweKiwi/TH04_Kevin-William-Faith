﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_Kevin_William_Faith
{
    public partial class Form1 : Form
    {
        List<Team> listTeam;
        List<string> listCountry;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Player> player1 = new List<Player> {
                new Player("David De Gea", "01", "GK"),
                new Player("Victor Lindelof", "02", "DF"),
                new Player("Phil Jones", "04", "DF"),
                new Player("Harry Maguire", "05", "DF"),
                new Player("Lisandro Martinez", "06", "DF"),
                new Player("Bruno Fernandez", "08", "MF"),
                new Player("Anthony Martial", "09", "FW"),
                new Player("Marcus Rashford", "10", "FW"),
                new Player("Tyrell Malacia", "12", "DF"),
                new Player("Christian Eriksen", "14", "MF"),
                new Player("Casemiro", "18", "MF")
            };
            List<Player> player2 = new List<Player> {
                new Player("Kepa Amizabalaga", "01", "GK"),
                new Player("Benoît Badiashile", "04", "DF"),
                new Player("Enzo Fernández", "05", "MF"),
                new Player("Thiago Silva", "06", "DF"),
                new Player("N'Golo Kanté", "07", "MF"),
                new Player("Mateo Kovačić", "08", "MF"),
                new Player("Pierre-Emerick Aubameyang", "09", "FW"),
                new Player("Christian Pulisic", "10", "MF"),
                new Player("João Félix", "11", "FW"),
                new Player("Ruben Loftus-Cheek", "12", "MF"),
                new Player("Raheem Sterling", "17", "MF")
            };
            List<Player> player3 = new List<Player> {
                new Player("Manuel Neuer", "01", "GK"),
                new Player("Dayot Upamecano", "02", "DF"),
                new Player("Matthijs de Ligt", "04", "GK"),
                new Player("Benjamin Pavard", "05", "GK"),
                new Player("Joshua Kimmich", "06", "MF"),
                new Player("Serge Gnabry", "07", "FW"),
                new Player("Leon Goretzka", "08", "MF"),
                new Player("Leroy Sané", "10", "FW"),
                new Player("Paul Wanner", "14", "MF"),
                new Player("Lucas Hernandez", "21", "DF"),
                new Player("Thomas Müller", "25", "FW")
            };
            Team team1 = new Team("Manchester United", "England", "Manchester", player1);
            Team team2 = new Team("Chelsea", "England", "Chelsea", player2);
            Team team3 = new Team("Bayern Munich", "Germany", "Munich", player3);

            listTeam = new List<Team> {team1,team2,team3};
            listCountry = new List<string> { "England", "Germany" };
            cbCountry.DataSource = listCountry;

            cbCountry.SelectedIndex = -1;
            cbTeam.SelectedIndex = -1;
            lbPlayer.Items.Clear();
        }

        private void cbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = (string)cbCountry.SelectedItem;
            List<Team> teamShow = new List<Team>();
            foreach(Team s in listTeam)
            {
                if(s.TeamCountry == selectedCountry)
                {
                    teamShow.Add(s);
                }
            }
            cbTeam.DataSource = teamShow;
            cbTeam.DisplayMember = "teamName";

        }

        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbPlayer.Items.Clear();
            Team selectedTeam = (Team)cbTeam.SelectedItem;
            if (selectedTeam.Players != null)
            {
                foreach (Player p in selectedTeam.Players)
                {
                    lbPlayer.Items.Add("(" + p.PlayerNum + ") " + p.PlayerName + ", " + p.PlayerPos);
                }
            }
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            if(tbTeamName.Text == ""||tbTeamCountry.Text == ""||tbTeamCity.Text == "")
            {
                MessageBox.Show("All fields must not be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool status = false;
                foreach (Team s in listTeam)
                {
                    if (s.TeamName == tbTeamName.Text)
                    {
                        status = true;
                        break;
                    }
                }
                if (status)
                {
                    MessageBox.Show("Team Name Already Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Team newTeam = new Team(tbTeamName.Text, tbTeamCountry.Text, tbTeamCity.Text, new List<Player>());
                    listTeam.Add(newTeam);
                    cbCountry.SelectedIndex = -1;

                    if (!listCountry.Contains(tbTeamCountry.Text))
                    {
                        listCountry.Add(tbTeamCountry.Text);
                        cbCountry.DataSource = null;
                        cbCountry.DataSource = listCountry;
                    }
                    tbTeamName.Text = "";
                    tbTeamCountry.Text = "";
                    tbTeamCity.Text = "";

                }
            }
        }

        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            if (tbPlayerName.Text == "" || tbPlayerNum.Text == "" || cbPlayerPos.SelectedItem == null)
            {
                MessageBox.Show("All fields must not be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool status = false;
                Team selectedTeam = (Team)cbTeam.SelectedItem;
                string playerPos = (string)cbPlayerPos.SelectedItem;
                Player newPlayer = new Player(tbPlayerName.Text, tbPlayerNum.Text, playerPos);
                foreach (Player p in selectedTeam.Players)
                {
                    if (p.PlayerName == tbPlayerName.Text || p.PlayerNum == tbPlayerNum.Text)
                    {
                        status = true;
                        break;
                    }
                }
                if (status)
                {
                    MessageBox.Show("Player or Number Already Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    selectedTeam.Players.Add(newPlayer);
                    lbPlayer.Items.Clear();
                    foreach (Player p in selectedTeam.Players)
                    {
                        lbPlayer.Items.Add("(" + p.PlayerNum + ") " + p.PlayerName + ", " + p.PlayerPos);
                    }
                    tbPlayerName.Text = "";
                    tbPlayerNum.Text = "";
                    cbPlayerPos.SelectedIndex = -1;
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int num = lbPlayer.SelectedIndex;
            Team selectedTeam = (Team)cbTeam.SelectedItem;
            if(selectedTeam.Players.Count > 11)
            {
                selectedTeam.Players.RemoveAt(num);
                lbPlayer.Items.Clear();
                foreach (Player p in selectedTeam.Players)
                {
                    lbPlayer.Items.Add("(" + p.PlayerNum + ") " + p.PlayerName + ", " + p.PlayerPos);
                }
            }
            else
            {
                MessageBox.Show("Number of players less than 11!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
